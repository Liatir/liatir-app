Square PNG logo exports with transparent background.
Folders:
- mono-color: single-color version
- normal: full/normal color version

File naming format: x<size>.png, e.g. x150.png.
Sizes included: 16, 32, 48, 64, 96, 128, 150, 180, 192, 256, 384, 512, 1024 px.
